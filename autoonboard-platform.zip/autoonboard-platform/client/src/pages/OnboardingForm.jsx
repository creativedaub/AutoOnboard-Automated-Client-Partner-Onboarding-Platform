import { useState } from "react";
import { useNavigate } from "react-router-dom";

const API = "http://localhost:4000/api";

export default function OnboardingForm() {
  const [form, setForm] = useState({ name: "", email: "", organization: "" });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    const res = await fetch(`${API}/onboarding/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setLoading(false);
    if (data.partnerId) navigate(`/status/${data.partnerId}`);
  }

  return (
    <main className="mx-auto max-w-md px-6 py-16">
      <h1 className="text-3xl font-bold">Start Partner Onboarding</h1>
      <p className="mt-2 text-slate-600">Form submission triggers personalized email sequence + document requests.</p>
      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <input required className="w-full rounded-lg border px-4 py-3" placeholder="Full name"
          value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
        <input required type="email" className="w-full rounded-lg border px-4 py-3" placeholder="Email"
          value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
        <input className="w-full rounded-lg border px-4 py-3" placeholder="Organization"
          value={form.organization} onChange={e => setForm({...form, organization: e.target.value})} />
        <button disabled={loading} className="w-full rounded-lg bg-indigo-600 py-3 font-semibold text-white">
          {loading ? "Starting…" : "Submit & Trigger Sequence"}
        </button>
      </form>
    </main>
  );
}
