import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const API = "http://localhost:4000/api";

export default function StatusPage() {
  const { id } = useParams();
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch(`${API}/onboarding/status/${id}`).then(r => r.json()).then(setData);
  }, [id]);

  if (!data) return <div className="p-10">Loading…</div>;

  return (
    <main className="mx-auto max-w-2xl px-6 py-12">
      <h1 className="text-2xl font-bold">{data.name} – Onboarding Status</h1>
      <p className="text-slate-600">{data.email} · {data.status}</p>

      <section className="mt-8">
        <h2 className="font-semibold">Email Sequence</h2>
        <ul className="mt-3 space-y-2">
          {data.sequence.map(s => (
            <li key={s.id} className="flex items-center gap-3 rounded-lg border bg-white p-3">
              <span className="text-sm font-medium">Step {s.step}</span>
              <span className="text-sm text-slate-600">{s.subject}</span>
              <span className="ml-auto rounded-full bg-green-50 px-2 py-0.5 text-xs text-green-700">{s.status}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-8">
        <h2 className="font-semibold">Documents</h2>
        <ul className="mt-3 space-y-2">
          {data.documents.map(d => (
            <li key={d.id} className="flex justify-between rounded-lg border bg-white p-3">
              <span>{d.name}</span>
              <span className="text-sm text-slate-500">{d.status}</span>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
