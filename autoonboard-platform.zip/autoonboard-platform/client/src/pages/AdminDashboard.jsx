import { useEffect, useState } from "react";

const API = "http://localhost:4000/api";

export default function AdminDashboard() {
  const [partners, setPartners] = useState([]);
  const [stats, setStats] = useState(null);

  useEffect(() => {
    Promise.all([
      fetch(`${API}/admin/partners`).then(r => r.json()),
      fetch(`${API}/admin/stats`).then(r => r.json()),
    ]).then(([p, s]) => { setPartners(p); setStats(s); });
  }, []);

  return (
    <main className="mx-auto max-w-5xl px-6 py-12">
      <h1 className="text-3xl font-bold">Admin Dashboard</h1>
      {stats && (
        <div className="mt-6 grid grid-cols-3 gap-4">
          <div className="rounded-xl border bg-white p-4"><div className="text-2xl font-bold">{stats.total}</div><div className="text-sm text-slate-500">Total Partners</div></div>
          <div className="rounded-xl border bg-white p-4"><div className="text-2xl font-bold">{stats.inProgress}</div><div className="text-sm text-slate-500">In Progress</div></div>
          <div className="rounded-xl border bg-white p-4"><div className="text-2xl font-bold">{stats.completed}</div><div className="text-sm text-slate-500">Completed</div></div>
        </div>
      )}
      <div className="mt-8 overflow-hidden rounded-xl border bg-white">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50"><tr><th className="px-4 py-3">Partner</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Emails</th><th className="px-4 py-3">Docs</th></tr></thead>
          <tbody>
            {partners.map(p => (
              <tr key={p.id} className="border-t">
                <td className="px-4 py-3"><div className="font-medium">{p.name}</div><div className="text-slate-500">{p.email}</div></td>
                <td className="px-4 py-3">{p.status}</td>
                <td className="px-4 py-3">{p.sequence?.length || 0}</td>
                <td className="px-4 py-3">{p.documents?.filter(d => d.status === "UPLOADED").length || 0}/{p.documents?.length || 0}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
