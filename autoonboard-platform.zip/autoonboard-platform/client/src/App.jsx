import { Routes, Route, Link } from "react-router-dom";
import OnboardingForm from "./pages/OnboardingForm";
import AdminDashboard from "./pages/AdminDashboard";
import StatusPage from "./pages/StatusPage";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <Link to="/" className="text-xl font-bold text-indigo-600">AutoOnboard</Link>
          <nav className="flex gap-4 text-sm">
            <Link to="/">Onboard</Link>
            <Link to="/admin">Admin</Link>
          </nav>
        </div>
      </header>
      <Routes>
        <Route path="/" element={<OnboardingForm />} />
        <Route path="/status/:id" element={<StatusPage />} />
        <Route path="/admin" element={<AdminDashboard />} />
      </Routes>
    </div>
  );
}
