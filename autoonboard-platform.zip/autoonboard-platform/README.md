# AutoOnboard – Automated Client & Partner Onboarding Platform

Form → Database → Personalized multi-step email sequence + document collection + real-time status tracking.

## Stack
- Backend: Node.js + Express + Prisma + PostgreSQL + Resend
- Frontend: React + Vite + Tailwind CSS

## Setup
1. Copy `.env.example` → `.env`
2. Backend: `cd server && npm i && npx prisma db push && npm run dev`
3. Frontend: `cd client && npm i && npm run dev`

## Core Flow
1. Partner submits form (`POST /api/onboarding/submit`)
2. System creates partner + required documents
3. Automated email sequence is triggered immediately
4. Admin dashboard shows real-time status & audit trail
