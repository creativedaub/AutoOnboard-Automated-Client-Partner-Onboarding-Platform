import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { PrismaClient } from "@prisma/client";
import onboardingRoutes from "./routes/onboarding.js";
import adminRoutes from "./routes/admin.js";

dotenv.config();
const app = express();
const prisma = new PrismaClient();

app.use(cors({ origin: process.env.CLIENT_URL }));
app.use(express.json());

app.use("/api/onboarding", onboardingRoutes);
app.use("/api/admin", adminRoutes);

app.get("/health", (_, res) => res.json({ status: "ok" }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`AutoOnboard API running on :${PORT}`));

export { prisma };
