import { Router } from "express";
import { z } from "zod";
import { PrismaClient } from "@prisma/client";
import { triggerSequence } from "../services/email.js";

const router = Router();
const prisma = new PrismaClient();

const submitSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  organization: z.string().optional(),
});

router.post("/submit", async (req, res) => {
  try {
    const data = submitSchema.parse(req.body);

    const partner = await prisma.partner.create({
      data: {
        name: data.name,
        email: data.email,
        organization: data.organization,
        status: "INVITED",
        documents: {
          create: [
            { name: "Signed Agreement", required: true },
            { name: "Tax Document", required: true },
            { name: "Insurance Certificate", required: false },
          ],
        },
      },
      include: { documents: true },
    });

    // Fire automated email sequence
    const emails = await triggerSequence(partner);

    // Record sequence steps
    await prisma.emailSequence.createMany({
      data: emails.map((e) => ({
        partnerId: partner.id,
        step: e.step,
        subject: e.subject,
        body: "",
        status: e.status,
        sentAt: new Date(),
      })),
    });

    await prisma.partner.update({
      where: { id: partner.id },
      data: { status: "IN_PROGRESS" },
    });

    res.json({ partnerId: partner.id, status: "IN_PROGRESS", emailsTriggered: emails.length });
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message });
  }
});

router.get("/status/:partnerId", async (req, res) => {
  const partner = await prisma.partner.findUnique({
    where: { id: req.params.partnerId },
    include: {
      sequence: { orderBy: { step: "asc" } },
      documents: true,
    },
  });
  if (!partner) return res.status(404).json({ error: "Not found" });
  res.json(partner);
});

export default router;
