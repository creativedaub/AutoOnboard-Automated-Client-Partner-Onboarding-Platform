import { Router } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/partners", async (_, res) => {
  const partners = await prisma.partner.findMany({
    include: {
      sequence: true,
      documents: true,
    },
    orderBy: { createdAt: "desc" },
  });
  res.json(partners);
});

router.get("/stats", async (_, res) => {
  const [total, inProgress, completed] = await Promise.all([
    prisma.partner.count(),
    prisma.partner.count({ where: { status: "IN_PROGRESS" } }),
    prisma.partner.count({ where: { status: "COMPLETED" } }),
  ]);
  res.json({ total, inProgress, completed });
});

export default router;
