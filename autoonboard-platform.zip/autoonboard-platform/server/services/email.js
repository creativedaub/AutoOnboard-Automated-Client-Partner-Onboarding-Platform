import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

const SEQUENCE = [
  {
    step: 1,
    subject: "Welcome – Let's get you onboarded",
    body: (name) => `Hi ${name},\n\nWelcome! Please complete your profile and upload the required documents.\n\nNext step: Upload signed agreement.`,
  },
  {
    step: 2,
    subject: "Document reminder – Action needed",
    body: (name) => `Hi ${name},\n\nWe still need your documents to proceed. Please upload them at your earliest convenience.`,
  },
  {
    step: 3,
    subject: "You're almost done!",
    body: (name) => `Hi ${name},\n\nFinal review is in progress. You'll receive confirmation once approved.`,
  },
];

export async function triggerSequence(partner) {
  const emails = [];
  for (const step of SEQUENCE) {
    const result = await resend.emails.send({
      from: "AutoOnboard <onboarding@autoonboard.example.org>",
      to: partner.email,
      subject: step.subject,
      text: step.body(partner.name),
    });
    emails.push({ step: step.step, subject: step.subject, status: "SENT" });
  }
  return emails;
}

export { SEQUENCE };
